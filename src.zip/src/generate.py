import json
import os
import time 
from tqdm import tqdm
import argparse
from pathlib import Path
from typing import Tuple
import pandas as pd
import torch
import transformers
from datasets import load_dataset
from transformers import LlamaForCausalLM, LlamaTokenizer, AutoTokenizer, AutoModel, AutoModelForCausalLM
import tensor_parallel as tp


def format_example(df, idx, include_answer=True, cot_flag=False):
    prompt = df.iloc[idx, 0]
    if cot_flag:
        prompt += "\nLet's think step by step and then give the answer."
    if include_answer:
        prompt += " {}\n\n".format(df.iloc[idx, 1])
    return prompt

def gen_prompt(train_df, subject, k=-1):
    if k > 0:
        prompt = "The following are multiple choice questions (with answers) about {}.\n\n".format(format_subject(subject))
    else:
        prompt = ""
    if k == -1:
        k = train_df.shape[0]
    for i in range(k):
        prompt += format_example(train_df, i)
    return prompt


def prepare_input(tokenizer, prompts):
    input_tokens = tokenizer.batch_encode_plus(prompts, return_tensors="pt", padding=True)
    for t in input_tokens:
        if torch.is_tensor(input_tokens[t]):
            input_tokens[t] = input_tokens[t].to('cuda')

    return input_tokens


def load(ckpt_dir, model_type):
    n_gpus = torch.cuda.device_count()
    
    if model_type == 'llama':
        # we use tensor parallel for loading llama
        model = LlamaForCausalLM.from_pretrained(ckpt_dir, low_cpu_mem_usage = True, torch_dtype=torch.float16)
        model = tp.tensor_parallel(model, [i for i in range(n_gpus)]) 
        tokenizer = LlamaTokenizer.from_pretrained(
        ckpt_dir,
        use_fast=False,
        padding_side="left",
        )
        tokenizer.pad_token_id = 0 if tokenizer.pad_token_id is None else tokenizer.pad_token_id
        tokenizer.bos_token_id = 1
    else:
        model = AutoModelForCausalLM.from_pretrained(ckpt_dir, device_map = 'balanced_low_0', torch_dtype=torch.float16, trust_remote_code=True)
        tokenizer = AutoTokenizer.from_pretrained(
        ckpt_dir,
        use_fast=False,
        padding_side="left",
        trust_remote_code=True
        )
        tokenizer.pad_token_id = 0 if tokenizer.pad_token_id is None else tokenizer.pad_token_id
        tokenizer.bos_token_id = 1
    model = model.bfloat16()
    model.eval()

    return model, tokenizer

def batch_split(prompts, batch_num, repeat_num=1):
    batch_prompts = []
    mini_batch = []
    for prompt in prompts:
        mini_batch.append(prompt)
        if len(mini_batch) == batch_num:
            repeat_batch = []
            for i in range(repeat_num):
                repeat_batch += mini_batch
            batch_prompts.append(repeat_batch)
            mini_batch = []
    if len(mini_batch) != 0:
        repeat_batch = []
        for i in range(repeat_num):
            repeat_batch += mini_batch
        batch_prompts.append(repeat_batch)
    print(batch_prompts)
    return batch_prompts



def batch_infer_with_results(model, tokenizer, prompts, max_new_tokens=200):
    batch_size = 1
    repeat_num = 2
    answers = []
    run_results = {}
    # prompts = prompts + prompts
    for batch_input in tqdm(batch_split(prompts, batch_size, repeat_num=repeat_num)):
        encode_inputs = prepare_input(tokenizer, batch_input)
        generation = model.generate(**encode_inputs, max_new_tokens=max_new_tokens, do_sample=True, temperature=0.7, top_p=1.0, top_k=50)
        answers.extend(tokenizer.batch_decode(generation, skip_special_tokens=True))
        for i in range(batch_size*repeat_num):
            idx = -1 - i
            print(answers[idx])
            print('-'*100)
    run_results['prompts'] = prompts
    run_results['pred_answers'] = answers
    # print(answers)
    return run_results


def main(ckpt_dir: str, param_size: str, model_type: str, output_file: str):
    
    # run_results = {}
    output_filename = 'run_results_%s_%sb.json' % (model_type, param_size)
    
    model, tokenizer = load(ckpt_dir, model_type)
    start_time = time.time()

    records = []
    dev_df = pd.read_json(args.train_dir, orient="records")
    test_df = pd.read_json(args.test_dir, orient="records")
    print(test_df.shape[0])
    for i in range(test_df.shape[0]):
        k = args.ntrain
        prompt_end = format_example(test_df, i, include_answer=False)
        train_prompt = gen_prompt(dev_df, 'gsm8k', k)
        prompt = train_prompt + prompt_end
        while len(tokenizer.tokenize(prompt)) + 1 > 2048: # bos token
            prompt_split = prompt.split("\n\n")
            prompt_split.pop(1)
            prompt = '\n\n'.join(prompt_split)
        label = test_df.iloc[i, test_df.shape[1]-1]
        records.append({'prompt':prompt, 'answer':label})
    gold_answers = [record['answer'] for record in records]
    prompts = [record['prompt'] for record in records]
    # print(prompts)
    # pred_answers = batch_infer(model, tokenizer, prompts)
    run_results = batch_infer_with_results(model, tokenizer, prompts, max_new_tokens=args.max_new_tokens)
    with open(output_filename, 'w') as f:
        json.dump(run_results, f, ensure_ascii=False, indent=2)
    
    end_time = time.time()
    print("total run time %.2f" % (end_time - start_time))
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--ckpt_dir', type=str, default='/aipublic/xuty_a/model/Qwen-7B-Chat')
    parser.add_argument('--output_file',type=str, default='sh_dx_1107_revise_Qwen7B.json')
    parser.add_argument('--param_size', type=str, default='7B')
    parser.add_argument('--model_type', type=str, default='qwen')
    parser.add_argument('--train_dir', type=str, default='/aipublic/jiachen/LLaMA-Factory/data/sh_dx_1107_revise.json')
    parser.add_argument('--test_dir', type=str, default='/aipublic/jiachen/LLaMA-Factory/data/sh_dx_1107_revise.json')
    parser.add_argument('--ntrain', type=int, default=0) # examples in-context
    parser.add_argument('--max_new_tokens', type=int, default=300)

    args = parser.parse_args()
    
    main(args.ckpt_dir, args.param_size, args.model_type, args.output_file)
