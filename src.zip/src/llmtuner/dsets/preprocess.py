import tiktoken
from typing import TYPE_CHECKING, Any, Dict, Generator, List, Literal, Union
from itertools import chain

from llmtuner.extras.constants import IGNORE_INDEX
from llmtuner.extras.template import get_template_and_fix_tokenizer

if TYPE_CHECKING:
    from datasets import Dataset, IterableDataset
    from transformers import Seq2SeqTrainingArguments
    from transformers.tokenization_utils import PreTrainedTokenizer
    from llmtuner.hparams import DataArguments

from datasets import concatenate_datasets, interleave_datasets, Dataset

def preprocess_dataset(
    dataset: Union["Dataset", "IterableDataset", "list"],
    tokenizer: "PreTrainedTokenizer",
    data_args: "DataArguments",
    training_args: "Seq2SeqTrainingArguments",
    stage: Literal["pt", "sft", "rm", "ppo", "cpl", "cmc", "mtl"]
) -> Union["Dataset", "IterableDataset"]:
    if isinstance(dataset, list) and stage == "cpl":
       	conlumn_names_1 = list(next(iter(dataset[0])).keys())
        conlumn_names_2 = list(next(iter(dataset[1])).keys())
    elif isinstance(dataset, list) and stage == "mtl":
        column_names = list(next(iter(dataset[0])).keys())
    else:
        column_names = list(next(iter(dataset)).keys())
    template = get_template_and_fix_tokenizer(data_args.template, tokenizer)

    if data_args.train_on_prompt and template.efficient_eos:
        raise ValueError("Current template does not support `train_on_prompt`.")

    def construct_example(examples: Dict[str, List[Any]], cot_flag=False) -> Generator[Any, None, None]:
        for i in range(len(examples["prompt"])):
            query, response = examples["prompt"][i], examples["response"][i]
            query = query + "\n" + examples["query"][i] if "query" in examples and examples["query"][i] else query
            if cot_flag:
                query += "\nLet's think step by step and then give the answer."
            history = examples["history"][i] if "history" in examples else None
            system = examples["system"][i] if "system" in examples else None
            yield query, response, history, system


    def preprocess_pretrain_dataset(examples: Dict[str, List[Any]]) -> Dict[str, Any]:
        # build grouped texts with format `X1 X2 X3 ...`
        if isinstance(getattr(tokenizer, "tokenizer", None), tiktoken.Encoding): # for tiktoken tokenizer (Qwen)
            kwargs = dict(allowed_special="all")
        else:
            kwargs = dict(add_special_tokens=True)

        if hasattr(tokenizer, "add_eos_token"): # for LLaMA tokenizer
            setattr(tokenizer, "add_eos_token", True)

        tokenized_examples = tokenizer(examples["prompt"], **kwargs)
        concatenated_examples = {k: list(chain(*tokenized_examples[k])) for k in tokenized_examples.keys()}
        total_length = len(concatenated_examples[list(concatenated_examples.keys())[0]])
        block_size = data_args.cutoff_len
        # we drop the small remainder, and if the total_length < block_size, we exclude this batch
        total_length = (total_length // block_size) * block_size
        # split by chunks of cutoff_len
        result = {
            k: [t[i: i + block_size] for i in range(0, total_length, block_size)]
            for k, t in concatenated_examples.items()
        }
        return result

    def preprocess_supervised_dataset(examples: Dict[str, List[Any]]) -> Dict[str, Any]:
        # build inputs with format `<bos> X Y <eos>` and labels with format `<ignore> ... <ignore> Y <eos>`
        # for multiturn examples, we only mask the prompt part in each prompt-response pair.
        model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}

        for query, response, history, system in construct_example(examples):
            input_ids, labels = [], []

            for turn_idx, (source_ids, target_ids) in enumerate(template.encode_multiturn(
                tokenizer, query, response, history, system
            )):
                total_len = len(source_ids) + len(target_ids)
                max_source_len = int(data_args.cutoff_len * (len(source_ids) / total_len))
                max_target_len = int(data_args.cutoff_len * (len(target_ids) / total_len))

                if len(source_ids) > max_source_len:
                    source_ids = source_ids[:max_source_len]
                if len(target_ids) > max_target_len:
                    target_ids = target_ids[:max_target_len]

                if data_args.train_on_prompt:
                    source_mask = source_ids
                elif turn_idx != 0 and template.efficient_eos:
                    source_mask = [tokenizer.eos_token_id] + [IGNORE_INDEX] * (len(source_ids) - 1)
                else:
                    source_mask = [IGNORE_INDEX] * len(source_ids)

                input_ids += source_ids + target_ids
                labels += source_mask + target_ids

            if template.efficient_eos:
                input_ids += [tokenizer.eos_token_id]
                labels += [tokenizer.eos_token_id]

            if len(input_ids) > data_args.cutoff_len:
                input_ids = input_ids[:data_args.cutoff_len]
                labels = labels[:data_args.cutoff_len]

            model_inputs["input_ids"].append(input_ids)
            model_inputs["attention_mask"].append([1] * len(input_ids))
            model_inputs["labels"].append(labels)

        return model_inputs
    
    def preprocess_step_supervised_dataset(examples: Dict[str, List[Any]]) -> Dict[str, Any]:
        model_inputs = {"input_ids": [], "answer_ids": [], "result_ids":[]}
        for query, response, history, system in construct_example(examples): # one problem
            encode_pairs, result_ids = template.encode_step(
                tokenizer, query, response
            )
            for step_idx, (source_ids, target_ids) in enumerate(encode_pairs):  #steps of reasoning

                if step_idx == len(encode_pairs) - 1 and template.efficient_eos:
                    target_ids += [tokenizer.eos_token_id]
                total_len = len(source_ids) + len(target_ids)
                max_source_len = int(data_args.cutoff_len * (len(source_ids) / total_len))
                max_target_len = int(data_args.cutoff_len * (len(target_ids) / total_len))

                if len(source_ids) > max_source_len:
                    source_ids = source_ids[:max_source_len]
                if len(target_ids) > max_target_len:
                    target_ids = target_ids[:max_target_len]
                
                model_inputs["input_ids"].append(source_ids)
                model_inputs["answer_ids"].append(target_ids)
                model_inputs["result_ids"].append(result_ids)
            
        return model_inputs

    def preprocess_packed_supervised_dataset(examples: Dict[str, List[Any]]) -> Dict[str, Any]:
        # build inputs with format `<bos> X1 Y1 <eos> <bos> X2 Y2 <eos>`
        # and labels with format `<ignore> ... <ignore> Y1 <eos> <ignore> ... <ignore> Y2 <eos>`
        model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}
        input_ids, labels = [], []
        for query, response, history, system in construct_example(examples):
            for turn_idx, (source_ids, target_ids) in enumerate(template.encode_multiturn(
                tokenizer, query, response, history, system
            )):
                if data_args.train_on_prompt:
                    source_mask = source_ids
                elif turn_idx != 0 and template.efficient_eos:
                    source_mask = [tokenizer.eos_token_id] + [IGNORE_INDEX] * (len(source_ids) - 1)
                else:
                    source_mask = [IGNORE_INDEX] * len(source_ids)
                input_ids += source_ids + target_ids
                labels += source_mask + target_ids

        if template.efficient_eos:
            input_ids += [tokenizer.eos_token_id]
            labels += [tokenizer.eos_token_id]

        total_length = len(input_ids)
        block_size = data_args.cutoff_len
        # we drop the small remainder, and if the total_length < block_size, we exclude this batch
        total_length = (total_length // block_size) * block_size
        # split by chunks of cutoff_len
        for i in range(0, total_length, block_size):
            model_inputs["input_ids"].append(input_ids[i: i + block_size])
            model_inputs["attention_mask"].append([1] * block_size)
            model_inputs["labels"].append(labels[i: i + block_size])

        return model_inputs

    def preprocess_unsupervised_dataset(examples: Dict[str, List[Any]]) -> Dict[str, Any]:
        # build inputs with format `<bos> X` and labels with format `Y <eos>`
        model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}

        for query, response, history, system in construct_example(examples):
            input_ids, labels = template.encode_oneturn(tokenizer, query, response, history, system)

            if template.efficient_eos:
                labels += [tokenizer.eos_token_id]

            if len(input_ids) > data_args.cutoff_len:
                input_ids = input_ids[:data_args.cutoff_len]
            if len(labels) > data_args.cutoff_len:
                labels = labels[:data_args.cutoff_len]

            model_inputs["input_ids"].append(input_ids)
            model_inputs["attention_mask"].append([1] * len(input_ids))
            model_inputs["labels"].append(labels)

        return model_inputs

    def preprocess_pairwise_dataset(examples):
        # build input pairs with format `<bos> X`, `Y1 <eos>` and `Y2 <eos>`
        model_inputs = {"prompt_ids": [], "chosen_ids": [], "rejected_ids": []}
        for query, response, history, system in construct_example(examples, cot_flag=True):
            prompt_ids, chosen_ids = template.encode_oneturn(tokenizer, query, response[0], history, system)
            _, rejected_ids = template.encode_oneturn(tokenizer, query, response[1], history, system)

            if template.efficient_eos:
                chosen_ids += [tokenizer.eos_token_id]
                rejected_ids += [tokenizer.eos_token_id]

            total_len = len(prompt_ids) + max(len(chosen_ids), len(rejected_ids))
            max_source_len = int(data_args.cutoff_len * (len(prompt_ids) / total_len))
            max_target_len = int(data_args.cutoff_len * (max(len(chosen_ids), len(rejected_ids)) / total_len))

            if len(prompt_ids) > max_source_len:
                prompt_ids = prompt_ids[:max_source_len]
            if len(chosen_ids) > max_target_len:
                chosen_ids = chosen_ids[:max_target_len]
            if len(rejected_ids) > max_target_len:
                rejected_ids = rejected_ids[:max_target_len]

            model_inputs["prompt_ids"].append(prompt_ids)
            model_inputs["chosen_ids"].append(chosen_ids)
            model_inputs["rejected_ids"].append(rejected_ids)
        return model_inputs
    
    def preprocess_sft_to_pairwise(examples):
        # model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}
        model_inputs = {"prompt_ids": [], "chosen_ids": [], "rejected_ids": []}

        for query, response, history, system in construct_example(examples, cot_flag=True):
            prompt_ids, chosen_ids, rejected_ids = [], [], []

            for turn_idx, (source_ids, target_ids) in enumerate(template.encode_multiturn(
                tokenizer, query, response, history, system
            )):
                total_len = len(source_ids) + len(target_ids)
                max_source_len = int(data_args.cutoff_len * (len(source_ids) / total_len))
                max_target_len = int(data_args.cutoff_len * (len(target_ids) / total_len))

                if len(source_ids) > max_source_len:
                    source_ids = source_ids[:max_source_len]
                if len(target_ids) > max_target_len:
                    target_ids = target_ids[:max_target_len]
                
                prompt_ids += source_ids 
                chosen_ids += target_ids

            response = "The question of the answer can only be solved by gussing.\nFor example, we can randomly give a result of 1000.\n#### 1000"
            for turn_idx, (source_ids, target_ids) in enumerate(template.encode_multiturn(
                tokenizer, query, response, history, system
            )):
                total_len = len(source_ids) + len(target_ids)
                max_target_len = int(data_args.cutoff_len * (len(target_ids) / total_len))
                if len(target_ids) > max_target_len:
                    target_ids = target_ids[:max_target_len]
                
                rejected_ids += target_ids

            if template.efficient_eos:
                prompt_ids += [tokenizer.eos_token_id]
                chosen_ids += [tokenizer.eos_token_id]
                rejected_ids += [tokenizer.eos_token_id]

            model_inputs["prompt_ids"].append(prompt_ids)
            model_inputs["chosen_ids"].append(chosen_ids)
            model_inputs["rejected_ids"].append(rejected_ids)

        return model_inputs    

    def combine_mtl_dataset(dataset_list):
        print("combining datasets")
        new_dataset = {}
        for idx in range(len(dataset_list)):
            input_ids_ = "input_ids" + "_%d"%idx
            attention_mask_ = "attention_mask" + "_%d"%idx
            labels_ = "labels" + "_%d"%idx
            new_dataset[input_ids_] = []
            new_dataset[attention_mask_] = []
            new_dataset[labels_] = []
        lengths = [dset.num_rows for dset in dataset_list]
        max_len = max(lengths)
        print("the maximum length of the dataset is %d"%max_len)
        for i, dset in enumerate(dataset_list): 
            input_ids_ = "input_ids" + "_%d"%i
            attention_mask_ = "attention_mask" + "_%d"%i
            labels_ = "labels" + "_%d"%i
            input_ids = dset["input_ids"]
            attention_mask = dset["attention_mask"]
            labels = dset["labels"]
            for idx in range(max_len):
                ids = (idx + 1) % dset.num_rows - 1
                new_dataset[input_ids_].append(input_ids[ids])
                new_dataset[attention_mask_].append(attention_mask[ids])
                new_dataset[labels_].append(labels[ids])

        new_dataset = Dataset.from_dict(new_dataset)
        print("combining dataset end")
        return new_dataset

    def print_supervised_dataset_example(example):
        print("input_ids:\n{}".format(example["input_ids"]))
        print("inputs:\n{}".format(tokenizer.decode(example["input_ids"], skip_special_tokens=False)))
        print('-'*100)
        print("label_ids:\n{}".format(example["labels"]))
        print("labels:\n{}".format(
            tokenizer.decode(list(filter(lambda x: x != IGNORE_INDEX, example["labels"])), skip_special_tokens=False)
        ))
        print('='*100)
    
    def print_mtl_dataset_example(example):
        for idx in range(len(example)//3):
            print("the %d-the task"%idx)
            print("input_ids:\n{}".format(example["input_ids"+"_%d"%idx]))
            print("inputs:\n{}".format(tokenizer.decode(example["input_ids"+"_%d"%idx], skip_special_tokens=False)))
            print("label_ids:\n{}".format(example["labels"+"_%d"%idx]))
            print("labels:\n{}".format(
                tokenizer.decode(list(filter(lambda x: x != IGNORE_INDEX, example["labels"+"_%d"%idx])), skip_special_tokens=False)
            ))

    def print_pairwise_dataset_example(example):
        print("prompt_ids:\n{}".format(example["prompt_ids"]))
        print("prompt:\n{}".format(tokenizer.decode(example["prompt_ids"], skip_special_tokens=False)))
        print("chosen_ids:\n{}".format(example["chosen_ids"]))
        print("chosen:\n{}".format(tokenizer.decode(example["chosen_ids"], skip_special_tokens=False)))
        print("rejected_ids:\n{}".format(example["rejected_ids"]))
        print("rejected:\n{}".format(tokenizer.decode(example["rejected_ids"], skip_special_tokens=False)))

    def print_unsupervised_dataset_example(example):
        print("input_ids:\n{}".format(example["input_ids"]))
        print("inputs:\n{}".format(tokenizer.decode(example["input_ids"], skip_special_tokens=False)))
    def print_step_dataset_example(example):
        print("input_ids:\n{}".format(example["input_ids"]))
        print("inputs:\n{}".format(tokenizer.decode(example["input_ids"], skip_special_tokens=False)))
        print('-'*100)
        print("answer_ids:\n{}".format(example["answer_ids"]))
        print("answers:\n{}".format(tokenizer.decode(example["answer_ids"], skip_special_tokens=False)))
        print('='*100)

    if stage == "pt":
        dataset = dataset.filter(lambda example: example["prompt"])
        preprocess_func = preprocess_pretrain_dataset
        print_function = print_unsupervised_dataset_example
    elif stage == "sft" and not training_args.predict_with_generate:
        dataset = dataset.filter(lambda example: example["prompt"] and example["response"])
        preprocess_func = preprocess_packed_supervised_dataset if data_args.sft_packing else preprocess_supervised_dataset
        print_function = print_supervised_dataset_example
    elif stage == "mtl":
        dataset = [dset.filter(lambda example: example["prompt"] and example["response"]) for dset in dataset]
        preprocess_func = preprocess_packed_supervised_dataset if data_args.sft_packing else preprocess_supervised_dataset
        print_function = print_mtl_dataset_example
    elif stage == "rm":
        dataset = dataset.filter(lambda example: example["prompt"] and len(example["response"]) > 1)
        preprocess_func = preprocess_pairwise_dataset
        print_function = print_pairwise_dataset_example
    elif stage == 'cpl':
        preprocess_func_sft = preprocess_sft_to_pairwise
        preprocess_func_cpl = preprocess_pairwise_dataset
        print_function = print_pairwise_dataset_example
    elif stage == 'cmc':
        preprocess_func = preprocess_step_supervised_dataset
        print_function = print_step_dataset_example
    else:
        dataset = dataset.filter(lambda example: example["prompt"])
        preprocess_func = preprocess_unsupervised_dataset
        print_function = print_unsupervised_dataset_example

    with training_args.main_process_first(desc="dataset map pre-processing"):
        kwargs = {}
        if not data_args.streaming:
            kwargs = dict(
                num_proc=data_args.preprocessing_num_workers,
                load_from_cache_file=not data_args.overwrite_cache,
                desc="Running tokenizer on dataset"
            )

        if stage == "cpl":
            if isinstance(dataset, list) and data_args.cpl_split == "all":
                for idx,dset in enumerate(dataset): 
                    if idx%2 == 0: ## the 1st is sft dataset
                        dataset_sft = dset.map(
                            preprocess_func_sft,
                            batched=True,            
                            remove_columns=conlumn_names_1,
                            **kwargs
                        )
                    else: ## the 2nd is parewise dataset
                        dataset_cpl = dset.map(
                            preprocess_func_cpl,
                            batched=True,            
                            remove_columns=conlumn_names_2,
                            **kwargs
                        )
                
                # dataset = concatenate_datasets([dataset_sft, dataset_cpl]) 
                # dataset = interleave_datasets([dataset_sft, dataset_cpl])
                if data_args.mix_strategy == "concat":
                    dataset = concatenate_datasets([dataset_sft, dataset_cpl])
                elif data_args.mix_strategy.startswith("interleave"):
                    stopping_strategy = "first_exhausted" if data_args.mix_strategy.endswith("under") else "all_exhausted"
                    dataset = interleave_datasets([dataset_sft, dataset_cpl], data_args.interleave_probs, stopping_strategy=stopping_strategy)
            elif data_args.cpl_split == "pairwise":
                dataset = dataset.map(
                    preprocess_func_cpl,
                    batched=True,            
                    remove_columns=column_names,
                    **kwargs
            )
            elif data_args.cpl_split == "sft":
                dataset = dataset.map(
                    preprocess_func_sft,
                    batched=True,            
                    remove_columns=conlumn_names,
                    **kwargs
                )
            else:
                raise ValueError("CPL datasets or CPL Split is wrongly set")
        elif stage == "mtl":
            dataset_list = []
            for idx, dset in enumerate(dataset):
                dset = dset.map(
                    preprocess_func,
                    batched=True,            
                    remove_columns=column_names,
                    **kwargs
                )
                dataset_list.append(dset)
            dataset = combine_mtl_dataset(dataset_list)
        else:
            dataset = dataset.map(
                preprocess_func,
                batched=True,            
                remove_columns=column_names,
                **kwargs
            )               
        try:
            for idx,example in enumerate(dataset):
                if idx < 5:
                    print_function(example)
                else:
                    break
        except StopIteration:
            raise ValueError("Empty dataset!")

        return dataset
