from llmtuner.tuner.cmc.workflow import run_cmc
