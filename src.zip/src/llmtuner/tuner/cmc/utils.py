import gc
import random
import warnings
from contextlib import contextmanager
from typing import List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F

from transformers.generation.stopping_criteria import StoppingCriteria, StoppingCriteriaList, \
    STOPPING_CRITERIA_INPUTS_DOCSTRING, add_start_docstrings


class StopAtSpecificTokenCriteria(StoppingCriteria):
    def __init__(self, token_id_list: list[int] = None):
        """
        :param token_id_list: id list of stop tokens
        """
        self.token_id_list = token_id_list

    @add_start_docstrings(STOPPING_CRITERIA_INPUTS_DOCSTRING)
    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor, **kwargs) -> bool:
        # return np.argmax(scores[-1].detach().cpu().numpy()) in self.token_id_list
        return input_ids[0][-1].detach().cpu().numpy() in self.token_id_list

class CMCDecorators(object):
    optimize_cuda_cache = False

    @classmethod
    @contextmanager
    def empty_cuda_cache(cls):
        yield
        if cls.optimize_cuda_cache and torch.cuda.is_available():
            gc.collect()
            torch.cuda.empty_cache()
            gc.collect()

def biased_bce_with_logits(adv1, adv2, y=0, bias=None):
    # Apply the log-sum-exp trick.
    # y = 1 if we prefer x2 to x1
    # We need to implement the numerical stability trick.
    if bias is not None:
        logit21 = adv2 - torch.mul(bias, adv1)
        logit12 = adv1 - torch.mul(bias, adv2)
    else:
        logit21 = adv2 - adv1
        logit12 = adv1 - adv2
    max21 = torch.clamp(-logit21, min=0, max=None)
    max12 = torch.clamp(-logit12, min=0, max=None)
    nlp21 = torch.log(torch.exp(-max21) + torch.exp(-logit21 - max21)) + max21
    nlp12 = torch.log(torch.exp(-max12) + torch.exp(-logit12 - max12)) + max12
    losses = y * nlp21 + (1 - y) * nlp12
    loss = losses.mean()

    # Now compute the accuracy
    # with torch.no_grad():
    #     accuracy = ((adv2 > adv1) == torch.round(y)).float().mean()

    return loss#, accuracy

def symmetric_KL_loss(p, q, pad_mask):
    """ symmetric KL-divergence 1/2*(KL(p||q)+KL(q||p)) 
    inputs: logits, logits, pad_mask
    """
    p = F.softmax(p, dim=-1)
    q = F.softmax(q, dim=-1)
    p, q, pad_mask = p.float(), q.float(), pad_mask.view(-1)
    dict_size = q.size(-1)
    non_pad_mask = ~pad_mask
    p = p.view(-1, dict_size)[non_pad_mask]
    q = q.view(-1, dict_size)[non_pad_mask]
    loss = (p - q) * (torch.log(p) - torch.log(q))

    return 0.5 * loss.sum()


def logprobs_from_logits(logits, labels, gather=True):
    """
    See: https://github.com/pytorch/pytorch/issues/563#issuecomment-330103591
    """
    logp = F.log_softmax(logits, dim=2)

    if not gather:
        return logp
    logpy = torch.gather(logp, 2, labels.unsqueeze(2)).squeeze(-1)
    return logpy
