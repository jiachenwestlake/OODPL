from llmtuner import export_model


def main():
    export_model()


if __name__ == "__main__":
    main()
